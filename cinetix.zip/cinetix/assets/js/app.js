document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('form').forEach(function (form) {
        form.addEventListener('submit', function () {
            const submit = form.querySelector('button[type="submit"]');
            if (submit && !form.classList.contains('filter-bar')) {
                submit.dataset.originalText = submit.textContent;
                submit.disabled = true;
                submit.textContent = 'Memproses...';
            }
        });
    });
});


/* CineTix light/dark theme switcher */
(function () {
    const STORAGE_KEY = 'cinetix-theme';
    const root = document.documentElement;

    function applyTheme(theme) {
        const selected = theme === 'light' ? 'light' : 'dark';
        root.setAttribute('data-theme', selected);
        document.querySelectorAll('[data-theme-icon]').forEach(function (el) {
            el.textContent = selected === 'dark' ? '☀' : '☾';
        });
        document.querySelectorAll('[data-theme-label]').forEach(function (el) {
            el.textContent = selected === 'dark' ? 'Mode cerah' : 'Mode gelap';
        });
        document.querySelectorAll('[data-theme-toggle]').forEach(function (el) {
            el.setAttribute('aria-label', selected === 'dark' ? 'Aktifkan mode cerah' : 'Aktifkan mode gelap');
            el.setAttribute('aria-pressed', selected === 'light' ? 'true' : 'false');
        });
    }

    let savedTheme = 'dark';
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored === 'light' || stored === 'dark') savedTheme = stored;
    } catch (e) {}

    applyTheme(savedTheme);

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('[data-theme-toggle]').forEach(function (button) {
            button.addEventListener('click', function () {
                const next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
                applyTheme(next);
                try { localStorage.setItem(STORAGE_KEY, next); } catch (e) {}
            });
        });
    });
})();


/* Interactive 20-seat cinema selector */
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.seat-booking-form').forEach(function (form) {
        const boxes = Array.from(form.querySelectorAll('input[name="seats[]"]'));
        const countText = form.querySelector('.seat-count-text');
        const submit = form.querySelector('button[type="submit"]');
        function refresh() {
            const selected = boxes.filter(function (box) { return box.checked; });
            if (countText) countText.textContent = selected.length
                ? selected.length + ' kursi dipilih: ' + selected.map(function (box) { return box.value; }).join(', ')
                : 'Belum ada kursi dipilih.';
            if (submit) {
                submit.disabled = selected.length === 0;
                submit.textContent = selected.length ? 'Pesan ' + selected.length + ' kursi' : 'Pesan kursi';
            }
        }
        boxes.forEach(function (box) {
            box.addEventListener('change', function () {
                const selected = boxes.filter(function (item) { return item.checked; });
                if (selected.length > 20) {
                    box.checked = false;
                    alert('Maksimal 20 kursi dalam satu pemesanan.');
                }
                refresh();
            });
        });
        refresh();
    });
});
