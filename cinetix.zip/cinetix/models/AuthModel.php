<?php
declare(strict_types=1);

class AuthModel {
    private PDO $db;
    public function __construct(PDO $db) { $this->db = $db; }

    public function loginAdmin(string $username, string $password): ?array {
        $stmt = $this->db->prepare("SELECT * FROM `admin` WHERE username = ? LIMIT 1");
        $stmt->execute([$username]);
        $row = $stmt->fetch();
        if (!$row || !password_verify($password, $row['password'])) return null;
        return ['id' => (int)$row['id_admin'], 'nama' => $row['nama_admin'], 'username' => $row['username'], 'role' => 'admin', 'admin_level' => ($row['role_admin'] ?? 'admin')];
    }

    public function loginUser(string $username, string $password): ?array {
        $stmt = $this->db->prepare(
            "SELECT id_user, nama, username, password FROM `user` WHERE username = ? LIMIT 1"
        );
        $stmt->execute([$username]);
        $row = $stmt->fetch();
        if (!$row || !password_verify($password, $row['password'])) return null;
        return [
            'id' => (int)$row['id_user'],
            'nama' => $row['nama'],
            'username' => $row['username'],
            'role' => 'user'
        ];
    }

    public function register(array $user, string $username, string $password): void {
        $stmt = $this->db->prepare(
            "INSERT INTO `user` (nama, email, no_hp, alamat, username, password)
             VALUES (:nama, :email, :no_hp, :alamat, :username, :password)"
        );
        $stmt->execute([
            ':nama' => $user['nama'],
            ':email' => $user['email'],
            ':no_hp' => $user['no_hp'],
            ':alamat' => $user['alamat'],
            ':username' => $username,
            ':password' => password_hash($password, PASSWORD_DEFAULT)
        ]);
    }

    public function usernameExists(string $username): bool {
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM `user` WHERE username = ? UNION ALL SELECT COUNT(*) FROM `admin` WHERE username = ?");
        $stmt->execute([$username, $username]);
        foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $count) if ((int)$count > 0) return true;
        return false;
    }

    public function emailExists(string $email): bool {
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM `user` WHERE email = ?");
        $stmt->execute([$email]);
        return (int)$stmt->fetchColumn() > 0;
    }
}
