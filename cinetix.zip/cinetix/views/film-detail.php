<?php showFlash(); ?>
<a class="back-link" href="index.php">← Kembali ke daftar film</a>
<?php if (!$detail): ?>
<div class="empty-state"><h2>Film tidak ditemukan</h2><a href="index.php">Kembali ke dashboard</a></div>
<?php else: ?>
<section class="film-detail">
    <div class="detail-poster">
        <?php if (!empty($detail['sampul'])): ?><img src="<?= e($detail['sampul']) ?>" alt="Poster <?= e($detail['judul']) ?>"><?php else: ?><div class="poster-placeholder"><strong><?= e($detail['judul']) ?></strong></div><?php endif; ?>
    </div>
    <div class="detail-content">
        <div class="eyebrow"><?= e($detail['genre']) ?></div>
        <h1><?= e($detail['judul']) ?></h1>
        <div class="director-line">Sutradara: <strong><?= e($detail['sutradara']) ?></strong></div>
        <h3>Sinopsis</h3>
        <p class="synopsis"><?= nl2br(e($detail['sinopsis'])) ?></p>
        <div class="schedule-heading"><div class="eyebrow">JADWAL PENAYANGAN</div><h2>Pilih jadwal dan tempat duduk</h2></div>
        <?php if (!currentUser()): ?><div class="login-hint">Masuk sebagai user untuk melakukan pemesanan tiket. <a href="index.php?page=login">Masuk sekarang</a></div><?php endif; ?>
        <?php if (!$schedules): ?><p class="muted">Belum ada jadwal tayang yang tersedia untuk film ini.</p><?php endif; ?>
        <?php foreach ($schedules as $schedule): $takenSeats = $occupiedSeatsBySchedule[(int)$schedule['id_jadwal']] ?? []; ?>
        <details class="schedule-seat-panel">
            <summary class="schedule-summary">
                <span><strong><?= date('d M Y', strtotime($schedule['tanggal_tayang'])) ?> · <?= substr($schedule['jam_tayang'],0,5) ?></strong><small><?= e($schedule['studio']) ?></small></span>
                <b class="price">Rp <?= number_format((float)$schedule['harga_tiket'],0,',','.') ?></b>
                <span class="choose-seat-label">Pilih kursi ↓</span>
            </summary>
            <?php if (isUser()): ?>
            <form method="post" action="index.php?page=book" class="seat-booking-form">
                <input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>">
                <input type="hidden" name="id_film" value="<?= (int)$detail['id_film'] ?>">
                <input type="hidden" name="id_jadwal" value="<?= (int)$schedule['id_jadwal'] ?>">
                <div class="seat-legend">
                    <span><i class="seat-dot available"></i> Tersedia</span>
                    <span><i class="seat-dot occupied"></i> Sudah dipesan</span>
                    <span><i class="seat-dot selected"></i> Pilihanmu</span>
                </div>
                <div class="screen-wrap"><div class="cinema-screen">LAYAR</div></div>
                <div class="seat-grid" data-seat-grid>
                    <?php foreach (['A','B','C','D'] as $row): ?>
                    <div class="seat-row">
                        <span class="seat-row-label"><?= $row ?></span>
                        <?php for ($col=1; $col<=5; $col++): $seat=$row.$col; $isTaken=in_array($seat,$takenSeats,true); ?>
                        <label class="seat-option <?= $isTaken ? 'is-occupied' : '' ?>">
                            <input type="checkbox" name="seats[]" value="<?= e($seat) ?>" <?= $isTaken ? 'disabled' : '' ?>>
                            <span><?= e($seat) ?></span>
                        </label>
                        <?php endfor; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="seat-booking-footer">
                    <span class="seat-count-text">Pilih kursi yang tersedia (maksimal 10).</span>
                    <button class="button-primary compact" type="submit" disabled>Pesan kursi</button>
                </div>
            </form>
            <?php else: ?>
            <p class="muted">Silakan masuk sebagai user untuk memilih kursi dan memesan tiket.</p>
            <?php endif; ?>
        </details>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>
