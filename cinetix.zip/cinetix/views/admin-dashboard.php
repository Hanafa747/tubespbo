<?php showFlash(); ?>
<div class="admin-welcome"><div><div class="eyebrow">OVERVIEW</div><h1>Dashboard Admin</h1><p>Ringkasan aktivitas dan pengelolaan CineTix.</p></div><div class="date-pill"><?= date('d F Y') ?></div></div>
<div class="stats-grid">
    <div class="stat-card"><span class="stat-icon">▣</span><small>Total Film</small><strong><?= $stats['film'] ?></strong><span class="stat-note">Film terdaftar</span></div>
    <div class="stat-card"><span class="stat-icon">♙</span><small>Total User</small><strong><?= $stats['user'] ?></strong><span class="stat-note">Pengguna terdaftar</span></div>
    <div class="stat-card"><span class="stat-icon">◷</span><small>Jadwal Tayang</small><strong><?= $stats['jadwal'] ?></strong><span class="stat-note">Seluruh jadwal</span></div>
    <div class="stat-card"><span class="stat-icon">▤</span><small>Pemesanan</small><strong><?= $stats['pemesanan'] ?></strong><span class="stat-note">Transaksi tercatat</span></div>
</div>
<section class="admin-panel">
    <div class="panel-heading"><div><div class="eyebrow">AKTIVITAS TERBARU</div><h2>Pemesanan terakhir</h2></div><a href="index.php?page=manage&entity=pemesanan">Kelola pemesanan →</a></div>
    <div class="table-scroll"><table><thead><tr><th>Pengguna</th><th>Film</th><th>Jadwal</th><th>Kursi</th><th>Jumlah</th><th>Total harga</th><th class="action-heading">Status / Aksi</th></tr></thead><tbody>
    <?php foreach ($recent as $item): ?><tr><td><?= e($item['nama'] ?? '-') ?></td><td><?= e($item['judul'] ?? '-') ?></td><td><?= e($item['tanggal_tayang'] ?? '-') ?> <?= e($item['jam_tayang'] ?? '') ?></td><td><?= e($item['daftar_kursi'] ?? '-') ?></td><td><?= (int)$item['jumlah_tiket'] ?></td><td>Rp <?= number_format((float)$item['total_harga'],0,',','.') ?></td><td class="row-actions"><?php if (($item['status'] ?? '') === 'menunggu konfirmasi'): ?>
        <div class="admin-order-actions">
            <form method="post" action="index.php?page=approve-order"><input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>"><input type="hidden" name="id_pemesanan" value="<?= (int)$item['id_pemesanan'] ?>"><button class="button-primary compact" type="submit" onclick="return confirm('Konfirmasi pembayaran pesanan ini?')">Konfirmasi</button></form>
            <form method="post" action="index.php?page=cancel-admin-order"><input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>"><input type="hidden" name="id_pemesanan" value="<?= (int)$item['id_pemesanan'] ?>"><button class="button-danger compact" type="submit" onclick="return confirm('Batalkan pesanan ini? Kursi akan tersedia kembali.')">Batalkan</button></form>
        </div>
        <?php else: ?><?= e($item['status'] ?? '-') ?><?php endif; ?></td></tr><?php endforeach; ?>
    <?php if (!$recent): ?><tr><td colspan="7" class="table-empty">Belum ada pemesanan.</td></tr><?php endif; ?>
    </tbody></table></div>
</section>
