<?php
function ticket_e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
$ticketSeats = $ticketOrder['kursi'] ?? [];
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Tiket CineTix #<?= (int)$ticketOrder['id_pemesanan'] ?></title>
<script>
(function(){
  try {
    var theme = localStorage.getItem('cinetix-theme') || 'dark';
    document.documentElement.setAttribute('data-theme', theme === 'light' ? 'light' : 'dark');
  } catch(e) {
    document.documentElement.setAttribute('data-theme', 'dark');
  }
})();
</script>
<style>
*{box-sizing:border-box}
:root{color-scheme:dark}
html[data-theme="light"]{color-scheme:light}
body{
 margin:0;min-height:100vh;padding:28px 18px 36px;
 background:#171717;color:#f5f5f5;
 font:14px Arial,Helvetica,sans-serif;
 transition:background .2s ease,color .2s ease
}
html[data-theme="light"] body{background:#f1f5fb;color:#203754}
.page-title{max-width:180mm;margin:0 auto 12px;text-align:center;font-size:12px;font-weight:700;color:#c6c6c6}
html[data-theme="light"] .page-title{color:#647891}

/* The on-screen and printed ticket use exactly the same physical dimensions. */
.ticket{
 width:180mm;max-width:100%;min-height:105mm;margin:0 auto;
 background:#fff;color:#172b45;border:1px solid #cbd7e5;border-radius:5mm;
 overflow:hidden;box-shadow:0 16px 42px rgba(0,0,0,.28);
 display:flex;flex-direction:column;
}
.ticket-head{
 min-height:23mm;padding:6mm 8mm;
 background:#0755a5!important;color:#fff!important;
 display:flex;justify-content:space-between;align-items:center;gap:10mm;
 -webkit-print-color-adjust:exact;print-color-adjust:exact;
}
.brand{font-size:23pt;font-weight:800;letter-spacing:-1px;color:#fff!important}
.brand span{color:#ffdb70!important}
.ticket-head small{display:block;opacity:.9;letter-spacing:2px;font-size:7pt;margin-top:2mm;color:#fff!important}
.status{
 padding:2.2mm 3.5mm;background:#e8f8ef!important;color:#237346!important;
 border-radius:99px;font-size:8pt;font-weight:700;white-space:nowrap;
 -webkit-print-color-adjust:exact;print-color-adjust:exact
}
.ticket-body{padding:7mm 8mm 6mm;flex:1}
.movie-title{font-size:18pt;line-height:1.2;margin:0 0 1.5mm;color:#173b63!important}
.sub{color:#73849a!important;margin:0 0 6mm;font-size:9pt}
.info-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:4.5mm 12mm}
.info label{display:block;color:#8291a5!important;font-size:7pt;text-transform:uppercase;letter-spacing:1px;margin-bottom:1mm}
.info strong{font-size:9.5pt;color:#243f5f!important}
.seats{
 margin:6mm 0 5mm;padding:4mm 5mm;border:1px dashed #b9cce1;border-radius:3mm;
 background:#f7faff!important;-webkit-print-color-adjust:exact;print-color-adjust:exact
}
.seats label{display:block;color:#71839a!important;font-size:7pt;text-transform:uppercase;letter-spacing:1px;margin-bottom:2.5mm}
.seat-list{display:flex;flex-wrap:wrap;gap:2mm}
.seat{
 padding:2mm 3.5mm;background:#e6f2ff!important;border:1px solid #b8d6f4;
 border-radius:2mm;color:#0755a5!important;font-weight:800;font-size:9pt;
 -webkit-print-color-adjust:exact;print-color-adjust:exact
}
.total{display:flex;justify-content:space-between;align-items:center;padding-top:4mm;border-top:1px solid #e7edf4;font-size:9pt;color:#172b45!important}
.total strong{font-size:17pt;color:#0755a5!important}
.ticket-foot{
 min-height:12mm;padding:3.5mm 8mm;background:#f2f6fb!important;color:#71839a!important;
 font-size:7.5pt;display:flex;justify-content:space-between;align-items:center;gap:5mm;
 -webkit-print-color-adjust:exact;print-color-adjust:exact
}
.actions{width:180mm;max-width:100%;margin:7mm auto 0;display:flex;gap:3mm;justify-content:flex-end}
button,.back{border:0;border-radius:2mm;padding:3mm 5mm;font-weight:700;cursor:pointer;text-decoration:none;font-size:9pt}
button{background:#0755a5;color:#fff}.back{background:#fff;color:#37516f;border:1px solid #d7e1ed}
@media(max-width:650px){
 body{padding:16px 10px 28px}
 .ticket{width:100%;min-height:0;border-radius:12px}
 .ticket-head{padding:16px 18px;min-height:70px}
 .ticket-body{padding:18px}
 .ticket-foot{padding:12px 18px}
 .movie-title{font-size:19px}
 .info-grid{gap:13px 12px}
 .actions{width:100%}
}
@page{size:A4 portrait;margin:15mm}
@media print{
 html,body{width:210mm;min-height:0;margin:0;padding:0!important;background:#fff!important;color:#172b45!important}
 body{-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}
 .page-title,.actions{display:none!important}
 .ticket{
   width:180mm!important;max-width:none!important;min-height:105mm!important;
   margin:0 auto!important;box-shadow:none!important;border:1px solid #cbd7e5!important;
   border-radius:5mm!important;break-inside:avoid;page-break-inside:avoid
 }
 .ticket-head,.status,.seats,.seat,.ticket-foot{
   -webkit-print-color-adjust:exact!important;print-color-adjust:exact!important;
 }
}
</style>
</head>
<body>
<div class="page-title">Tiket CineTix #<?= (int)$ticketOrder['id_pemesanan'] ?></div>
<article class="ticket">
    <header class="ticket-head">
        <div><div class="brand">Cine<span>Tix</span></div><small>OFFICIAL MOVIE TICKET</small></div>
        <span class="status">PEMBAYARAN SELESAI</span>
    </header>
    <section class="ticket-body">
        <h1 class="movie-title"><?= ticket_e($ticketOrder['judul']) ?></h1>
        <p class="sub">Tunjukkan tiket ini kepada petugas sebelum memasuki studio.</p>
        <div class="info-grid">
            <div class="info"><label>Nomor pesanan</label><strong>#<?= (int)$ticketOrder['id_pemesanan'] ?></strong></div>
            <div class="info"><label>Nama pemesan</label><strong><?= ticket_e($ticketOrder['nama']) ?></strong></div>
            <div class="info"><label>Tanggal tayang</label><strong><?= date('d F Y',strtotime($ticketOrder['tanggal_tayang'])) ?></strong></div>
            <div class="info"><label>Jam tayang</label><strong><?= substr($ticketOrder['jam_tayang'],0,5) ?> WIB</strong></div>
            <div class="info"><label>Studio</label><strong><?= ticket_e($ticketOrder['studio']) ?></strong></div>
            <div class="info"><label>Jumlah tiket</label><strong><?= (int)$ticketOrder['jumlah_tiket'] ?> tiket</strong></div>
        </div>
        <div class="seats"><label>Nomor kursi</label><div class="seat-list"><?php foreach($ticketSeats as $seat): ?><span class="seat"><?= ticket_e($seat) ?></span><?php endforeach; ?></div></div>
        <div class="total"><span>Total pembayaran</span><strong>Rp <?= number_format((float)$ticketOrder['total_harga'],0,',','.') ?></strong></div>
    </section>
    <footer class="ticket-foot"><span>CineTix · Temukan film. Pilih jadwal. Nikmati cerita.</span><span>Pesanan #<?= (int)$ticketOrder['id_pemesanan'] ?></span></footer>
</article>
<div class="actions"><a class="back" href="javascript:window.close()">Tutup</a><button type="button" onclick="window.print()">Cetak tiket</button></div>
<script>window.addEventListener('load',function(){setTimeout(function(){window.print()},400)});</script>
</body>
</html>
