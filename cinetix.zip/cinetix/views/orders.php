<?php
$activeTab = in_array(($_GET['tab'] ?? 'pending'), ['pending','confirm','done'], true) ? ($_GET['tab'] ?? 'pending') : 'pending';
showFlash();
?>
<div class="orders-heading">
    <div><div class="eyebrow">AKTIVITAS AKUN</div><h1>Pesanan Saya</h1><p>Periksa pembayaran dan riwayat pemesanan tiketmu.</p></div>
    <a class="button-quiet" href="index.php">← Kembali ke film</a>
</div>
<nav class="order-tabs">
    <a class="<?= $activeTab === 'pending' ? 'active' : '' ?>" href="index.php?page=orders&tab=pending">Perlu Dibayar <span><?= count($pendingOrders) ?></span></a>
    <a class="<?= $activeTab === 'confirm' ? 'active' : '' ?>" href="index.php?page=orders&tab=confirm">Menunggu Konfirmasi <span><?= count($confirmationOrders) ?></span></a>
    <a class="<?= $activeTab === 'done' ? 'active' : '' ?>" href="index.php?page=orders&tab=done">Selesai <span><?= count($completedOrders) ?></span></a>
</nav>
<?php $list = $activeTab === 'pending' ? $pendingOrders : ($activeTab === 'confirm' ? $confirmationOrders : $completedOrders); ?>
<div class="orders-list">
<?php foreach ($list as $order): ?>
    <article class="order-card">
        <div class="order-poster">
            <?php if (!empty($order['sampul'])): ?><img src="<?= e($order['sampul']) ?>" alt="<?= e($order['judul']) ?>"><?php else: ?><span>C</span><?php endif; ?>
        </div>
        <div class="order-main">
            <div class="order-meta"><span class="order-number">Pemesanan #<?= (int)$order['id_pemesanan'] ?></span><span class="status-pill <?= $activeTab === 'done' ? 'done' : 'waiting' ?>"><?= e($order['status']) ?></span></div>
            <h2><?= e($order['judul']) ?></h2>
            <p><?= date('d M Y', strtotime($order['tanggal_tayang'])) ?> · <?= substr($order['jam_tayang'],0,5) ?> · <?= e($order['studio']) ?></p>
            <small><?= (int)$order['jumlah_tiket'] ?> tiket · Kursi: <?= e($order['daftar_kursi'] ?: '-') ?> · Rp <?= number_format((float)$order['total_harga'],0,',','.') ?></small>
        </div>
        <?php if ($activeTab === 'pending'): ?>
            <a class="button-primary compact" href="index.php?page=orders&show=<?= (int)$order['id_pemesanan'] ?>&tab=pending">Lihat & bayar</a>
        <?php elseif ($activeTab === 'confirm'): ?>
            <span class="status-pill waiting">Kursi ditahan · Menunggu admin</span>
        <?php else: ?>
            <a class="button-primary compact print-ticket-button" href="index.php?page=print-ticket&id=<?= (int)$order['id_pemesanan'] ?>" target="_blank" rel="noopener">▣ Cetak Tiket</a>
        <?php endif; ?>
    </article>
<?php endforeach; ?>
<?php if (!$list): ?><div class="empty-state"><div class="empty-icon"><?= $activeTab === 'pending' ? '◷' : '✓' ?></div><h3><?= $activeTab === 'pending' ? 'Tidak ada pesanan yang perlu dibayar' : ($activeTab === 'confirm' ? 'Belum ada pembayaran yang menunggu konfirmasi' : 'Belum ada pesanan selesai') ?></h3><p><?= $activeTab === 'pending' ? 'Pesanan baru akan muncul di sini setelah kamu memilih jadwal film.' : ($activeTab === 'confirm' ? 'Pesanan akan selesai setelah administrator mengonfirmasi pembayaran.' : 'Pesanan yang sudah dikonfirmasi administrator akan tampil di sini.') ?></p><a href="index.php">Cari film</a></div><?php endif; ?>
</div>
<?php if ($showOrder && $showOrder['status'] === 'menunggu pembayaran'): ?>
<div class="order-modal-backdrop" id="orderModal">
    <section class="order-modal" role="dialog" aria-modal="true" aria-labelledby="orderModalTitle">
        <button type="button" class="modal-close" onclick="window.location.href='index.php?page=orders'">×</button>
        <div class="eyebrow">KONFIRMASI PESANAN</div>
        <h2 id="orderModalTitle">Ringkasan pesanan</h2>
        <p class="modal-subtitle">Periksa kembali detail tiket sebelum melanjutkan pembayaran.</p>
        <div class="modal-film">
            <?php if (!empty($showOrder['sampul'])): ?><img src="<?= e($showOrder['sampul']) ?>" alt="<?= e($showOrder['judul']) ?>"><?php endif; ?>
            <div><strong><?= e($showOrder['judul']) ?></strong><span><?= e($showOrder['studio']) ?></span><span><?= date('d M Y', strtotime($showOrder['tanggal_tayang'])) ?> · <?= substr($showOrder['jam_tayang'],0,5) ?></span></div>
        </div>
        <div class="order-summary">
            <div><span>Nama pemesan</span><strong><?= e($showOrder['nama']) ?></strong></div>
            <div><span>Email</span><strong><?= e($showOrder['email']) ?></strong></div>
            <div><span>Nomor pemesanan</span><strong>#<?= (int)$showOrder['id_pemesanan'] ?></strong></div>
            <div><span>Nomor kursi</span><strong><?= e(implode(', ', $showOrder['kursi'])) ?></strong></div>
            <div><span>Jumlah tiket</span><strong><?= (int)$showOrder['jumlah_tiket'] ?> tiket</strong></div>
            <div><span>Harga per tiket</span><strong>Rp <?= number_format((float)$showOrder['harga_tiket'],0,',','.') ?></strong></div>
            <div class="summary-total"><span>Total pembayaran</span><strong>Rp <?= number_format((float)$showOrder['total_harga'],0,',','.') ?></strong></div>
        </div>
        <div class="pending-note"><span class="status-pill waiting">Menunggu pembayaran</span><small>Kursi sudah ditahan untuk pesanan ini. Setelah kamu menyatakan sudah membayar, administrator akan memeriksa dan mengonfirmasi pembayaran.</small></div>
        <form method="post" action="index.php?page=pay" class="modal-actions">
            <input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>">
            <input type="hidden" name="id_pemesanan" value="<?= (int)$showOrder['id_pemesanan'] ?>">
            <button class="button-primary pay-button" type="submit" onclick="return confirm('Kirim konfirmasi bahwa pembayaran sudah dilakukan?')">Saya sudah bayar</button>
        </form>
        <form method="post" action="index.php?page=cancel-order" class="cancel-order-form">
            <input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>">
            <input type="hidden" name="id_pemesanan" value="<?= (int)$showOrder['id_pemesanan'] ?>">
            <button type="submit" onclick="return confirm('Batalkan pesanan ini? Kursi yang dipilih akan tersedia kembali.')">Batal pesan</button>
        </form>
        <p class="payment-disclaimer">Pembayaran pada versi tugas ini merupakan simulasi konfirmasi, belum terhubung ke layanan pembayaran online.</p>
    </section>
</div>
<?php endif; ?>
