</main>
</div>
<footer class="site-footer">© <?= date('Y') ?> CineTix <span>•</span> Temukan film. Pilih jadwal. Nikmati cerita.</footer>
<script src="assets/js/app.js?v=20261116-dualtheme"></script>
</body>
</html>
