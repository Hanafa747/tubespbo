<?php
declare(strict_types=1);

class BookingController {
    private PDO $db;
    private const SEATS = [
        'A1','A2','A3','A4','A5',
        'B1','B2','B3','B4','B5',
        'C1','C2','C3','C4','C5',
        'D1','D2','D3','D4','D5'
    ];

    public function __construct(PDO $db) { $this->db = $db; }

    public function allSeats(): array { return self::SEATS; }

    public function occupiedSeats(int $idJadwal): array {
        $stmt = $this->db->prepare(
            "SELECT pk.nomor_kursi
             FROM pemesanan_kursi pk
             INNER JOIN pemesanan p ON p.id_pemesanan=pk.id_pemesanan
             WHERE pk.id_jadwal=?"
        );
        $stmt->execute([$idJadwal]);
        return array_column($stmt->fetchAll(), 'nomor_kursi');
    }

    public function create(int $idUser, int $idJadwal, array $seats): int {
        $seats = array_values(array_unique(array_map('strval', $seats)));
        if (count($seats) < 1 || count($seats) > 20) {
            throw new RuntimeException('Pilih minimal 1 dan maksimal 20 kursi untuk satu pemesanan.');
        }
        foreach ($seats as $seat) {
            if (!in_array($seat, self::SEATS, true)) {
                throw new RuntimeException('Pilihan kursi tidak valid.');
            }
        }

        $this->db->beginTransaction();
        try {
            $stmt = $this->db->prepare(
                "SELECT id_film, harga_tiket, tanggal_tayang FROM jadwal_tayang WHERE id_jadwal=? FOR UPDATE"
            );
            $stmt->execute([$idJadwal]);
            $schedule = $stmt->fetch();
            if (!$schedule) throw new RuntimeException('Jadwal tidak ditemukan.');
            if ($schedule['tanggal_tayang'] < date('Y-m-d')) throw new RuntimeException('Jadwal tersebut sudah lewat.');

            $marks = implode(',', array_fill(0, count($seats), '?'));
            $check = $this->db->prepare(
                "SELECT nomor_kursi FROM pemesanan_kursi WHERE id_jadwal=? AND nomor_kursi IN ($marks) FOR UPDATE"
            );
            $check->execute(array_merge([$idJadwal], $seats));
            $taken = array_column($check->fetchAll(), 'nomor_kursi');
            if ($taken) throw new RuntimeException('Kursi berikut sudah dipesan: ' . implode(', ', $taken) . '. Silakan pilih kursi lain.');

            $total = (float)$schedule['harga_tiket'] * count($seats);
            $stmt = $this->db->prepare(
                "INSERT INTO pemesanan (id_user,id_film,id_jadwal,tanggal_pemesanan,jumlah_tiket,total_harga,status)
                 VALUES (?,?,?,?,?,?,'menunggu pembayaran')"
            );
            $stmt->execute([$idUser, $schedule['id_film'], $idJadwal, date('Y-m-d H:i:s'), count($seats), $total]);
            $idPemesanan = (int)$this->db->lastInsertId();

            $insertSeat = $this->db->prepare(
                "INSERT INTO pemesanan_kursi (id_pemesanan,id_jadwal,nomor_kursi) VALUES (?,?,?)"
            );
            foreach ($seats as $seat) $insertSeat->execute([$idPemesanan, $idJadwal, $seat]);

            $this->db->commit();
            return $idPemesanan;
        } catch (Throwable $ex) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            if ($ex instanceof PDOException && str_contains($ex->getMessage(), 'uq_jadwal_kursi')) {
                throw new RuntimeException('Salah satu kursi baru saja dipesan pengguna lain. Silakan muat ulang dan pilih kursi lain.');
            }
            throw $ex;
        }
    }

    public function seatsForOrder(int $idPemesanan): array {
        $stmt = $this->db->prepare("SELECT nomor_kursi FROM pemesanan_kursi WHERE id_pemesanan=? ORDER BY nomor_kursi");
        $stmt->execute([$idPemesanan]);
        return array_column($stmt->fetchAll(), 'nomor_kursi');
    }

    public function findForUser(int $idPemesanan, int $idUser): ?array {
        $stmt = $this->db->prepare(
            "SELECT p.*, u.nama, u.email, u.no_hp, f.judul, f.sampul, j.studio, j.tanggal_tayang, j.jam_tayang, j.harga_tiket
             FROM pemesanan p
             INNER JOIN `user` u ON u.id_user=p.id_user
             INNER JOIN film f ON f.id_film=p.id_film
             INNER JOIN jadwal_tayang j ON j.id_jadwal=p.id_jadwal
             WHERE p.id_pemesanan=? AND p.id_user=? LIMIT 1"
        );
        $stmt->execute([$idPemesanan, $idUser]);
        $order = $stmt->fetch();
        if ($order) $order['kursi'] = $this->seatsForOrder($idPemesanan);
        return $order ?: null;
    }

    public function findCompletedForUser(int $idPemesanan, int $idUser): ?array {
        $order = $this->findForUser($idPemesanan, $idUser);
        return ($order && $order['status'] === 'selesai') ? $order : null;
    }

    public function listForUser(int $idUser, string $status): array {
        $stmt = $this->db->prepare(
            "SELECT p.*, f.judul, f.sampul, j.studio, j.tanggal_tayang, j.jam_tayang,
                    (SELECT GROUP_CONCAT(pk.nomor_kursi ORDER BY pk.nomor_kursi SEPARATOR ', ')
                     FROM pemesanan_kursi pk WHERE pk.id_pemesanan=p.id_pemesanan) AS daftar_kursi
             FROM pemesanan p
             INNER JOIN film f ON f.id_film=p.id_film
             INNER JOIN jadwal_tayang j ON j.id_jadwal=p.id_jadwal
             WHERE p.id_user=? AND p.status=?
             ORDER BY p.id_pemesanan DESC"
        );
        $stmt->execute([$idUser, $status]);
        return $stmt->fetchAll();
    }

    public function pay(int $idPemesanan, int $idUser): void {
        $stmt = $this->db->prepare(
            "UPDATE pemesanan SET status='menunggu konfirmasi' WHERE id_pemesanan=? AND id_user=? AND status='menunggu pembayaran'"
        );
        $stmt->execute([$idPemesanan, $idUser]);
        if ($stmt->rowCount() !== 1) throw new RuntimeException('Pesanan tidak ditemukan atau sudah diproses.');
    }

    public function cancel(int $idPemesanan, int $idUser): void {
        $stmt = $this->db->prepare(
            "DELETE FROM pemesanan WHERE id_pemesanan=? AND id_user=? AND status='menunggu pembayaran'"
        );
        $stmt->execute([$idPemesanan, $idUser]);
        if ($stmt->rowCount() !== 1) throw new RuntimeException('Pesanan tidak ditemukan atau tidak dapat dibatalkan.');
    }
}
