-- CineTix: tabel pemilihan kursi bioskop
-- Import file ini melalui phpMyAdmin ke database cinetix yang sudah digunakan.
-- Tidak menghapus tabel atau data lama.
USE cinetix;

CREATE TABLE IF NOT EXISTS pemesanan_kursi (
    id_detail_kursi INT AUTO_INCREMENT PRIMARY KEY,
    id_pemesanan INT NOT NULL,
    id_jadwal INT NOT NULL,
    nomor_kursi ENUM(
        'A1','A2','A3','A4','A5',
        'B1','B2','B3','B4','B5',
        'C1','C2','C3','C4','C5',
        'D1','D2','D3','D4','D5'
    ) NOT NULL,
    tanggal_dibuat DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_jadwal_kursi UNIQUE (id_jadwal, nomor_kursi),
    CONSTRAINT fk_kursi_pemesanan
        FOREIGN KEY (id_pemesanan) REFERENCES pemesanan(id_pemesanan)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_kursi_jadwal
        FOREIGN KEY (id_jadwal) REFERENCES jadwal_tayang(id_jadwal)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
