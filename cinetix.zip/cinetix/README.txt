CINETIX — WEBSITE PEMESANAN TIKET BIOSKOP
==========================================

TEKNOLOGI
- PHP 8.0+
- MySQL / MariaDB
- XAMPP (Apache dan MySQL)
- PDO untuk koneksi database
- MVC: Model, Controller, View

PENTING: DATABASE DIBUAT MANUAL OLEH PENGGUNA
Website ini TIDAK mengimpor atau membuat database secara otomatis. Database `cinetix` dan keenam tabel harus sudah dibuat di phpMyAdmin.

STRUKTUR DATABASE YANG DIHARAPKAN

1. Tabel `user`
   - id_user INT (PK, AUTO_INCREMENT)
   - nama VARCHAR(100)
   - email VARCHAR(100)
   - no_hp VARCHAR(15)
   - alamat TEXT

2. Tabel `film`
   - id_film INT (PK, AUTO_INCREMENT)
   - sampul VARCHAR(255)
   - judul VARCHAR(150)
   - genre VARCHAR(50)
   - sutradara VARCHAR(100)
   - sinopsis TEXT

3. Tabel `jadwal_tayang`
   - id_jadwal INT (PK, AUTO_INCREMENT)
   - id_film INT (FK ke film.id_film)
   - studio VARCHAR(50)
   - tanggal_tayang DATE
   - jam_tayang TIME
   - harga_tiket DECIMAL(10,2)

4. Tabel `pemesanan`
   - id_pemesanan INT (PK, AUTO_INCREMENT)
   - id_user INT (FK ke user.id_user)
   - id_film INT (FK ke film.id_film)
   - id_jadwal INT (FK ke jadwal_tayang.id_jadwal)
   - tanggal_pemesanan DATETIME
   - jumlah_tiket INT
   - total_harga DECIMAL(10,2)

5. Tabel `akun`
   - id_akun INT (PK, AUTO_INCREMENT)
   - id_user INT (FK ke user.id_user)
   - username VARCHAR(50)
   - password VARCHAR(255)
   - tanggal_dibuat DATETIME DEFAULT CURRENT_TIMESTAMP

6. Tabel `admin`
   - id_admin INT (PK, AUTO_INCREMENT)
   - nama_admin VARCHAR(100)
   - username VARCHAR(50)
   - password VARCHAR(255)
   - tanggal_dibuat DATETIME DEFAULT CURRENT_TIMESTAMP

CATATAN DATABASE
- Gunakan InnoDB untuk semua tabel.
- Kolom FK harus memiliki tipe data yang sama dengan kolom PK tujuan.
- `akun.username` dan `admin.username` sebaiknya diberi UNIQUE.
- `user.email` sebaiknya diberi UNIQUE.
- `akun.id_user` sebaiknya diberi UNIQUE agar satu user memiliki satu akun.
- `tanggal_dibuat` pada akun dan admin diisi otomatis dengan DEFAULT CURRENT_TIMESTAMP.
- `pemesanan.id_film` harus cocok dengan `jadwal_tayang.id_film` untuk jadwal yang dipilih.
- Password di tabel akun dan admin harus VARCHAR(255), karena aplikasi menyimpan password hash.

CARA MENJALANKAN
1. Ekstrak folder CineTix_Web ke C:\xampp\htdocs.
2. Jalankan Apache dan MySQL di XAMPP.
3. Pastikan database `cinetix` dan tabel-tabelnya sudah dibuat di phpMyAdmin.
4. Buka config/database.php. Sesuaikan host, username, dan password MySQL jika diperlukan.
5. Buka http://localhost/CineTix_Web/buat_admin_awal.php satu kali.
6. Jika muncul pesan berhasil, HAPUS file buat_admin_awal.php.
7. Buka http://localhost/CineTix_Web/.

AKUN ADMIN AWAL
Username: admin
Password: admin123
Login pilih role Administrator.

REGISTRASI USER
- User mengisi nama, email, nomor HP, alamat, username, password, dan confirm password.
- Nama lengkap, email, no_hp, dan alamat disimpan ke tabel `user`.
- Username, password hash, serta id_user hasil insert disimpan ke tabel `akun`.
- Username dan password hash disimpan di tabel `akun`.
- tanggal_dibuat otomatis oleh MySQL.

FITUR
- Dashboard katalog film.
- Pencarian judul film dan filter genre, bisa digunakan bersamaan.
- Detail film, poster, sutradara, sinopsis, dan jadwal.
- Upload poster film JPG, PNG, WEBP maksimal 4 MB.
- Login terpisah untuk admin dan user.
- Registrasi user dengan konfirmasi password.
- Pemesanan tiket oleh user yang login.
- Admin dashboard dengan ringkasan data.
- CRUD keenam tabel: user, film, jadwal_tayang, pemesanan, akun, admin.
- User tidak mendapatkan menu pengelolaan admin.
- Password di-hash menggunakan password_hash dan diverifikasi dengan password_verify.

CATATAN
- Proyek ini disusun untuk tugas kuliah. Pengujian langsung dengan struktur database milik pengguna tetap perlu dilakukan.
- Penghapusan data yang masih direferensikan oleh tabel lain dapat ditolak oleh aturan Foreign Key.
- Fitur pembayaran online, pemilihan kursi, dan pencetakan e-ticket belum termasuk dalam lingkup fitur ini.
- Untuk penggunaan publik, tambahkan verifikasi email, pembatasan percobaan login, dan pengamanan produksi lainnya.


PERUBAHAN STRUKTUR AKUN USER:
- Akun user sekarang disimpan langsung di tabel `user`.
- Tabel `akun` tidak lagi digunakan oleh aplikasi dan boleh dihapus setelah migrasi data.
- Tabel `user` harus memiliki kolom `username` VARCHAR(50) UNIQUE dan `password` VARCHAR(255).
- Registrasi menyimpan identitas dan kredensial dalam satu baris tabel `user`.
- Password tetap disimpan sebagai hash menggunakan password_hash().
- Menu Data Akun User dihapus; username tampil di Data User. Password tidak ditampilkan sebagai teks asli.
- Untuk mengubah password di halaman Data User, isi password baru; kosongkan jika tidak ingin mengubahnya.

Jalankan SQL migrasi yang diberikan terpisah sebelum menggunakan versi aplikasi ini.

LANGKAH MIGRASI DATABASE:
1. Backup database cinetix melalui phpMyAdmin > Export.
2. Buka database cinetix > tab SQL.
3. Jalankan isi file MIGRASI_DATABASE.sql.
4. Setelah berhasil, ganti folder/file proyek dengan versi ZIP ini.
5. Kolom password di tabel web ditampilkan tersamarkan; isi password baru pada form Edit untuk menggantinya.


FITUR PESANAN USER:
- Setelah user memesan tiket, aplikasi membuat satu baris pemesanan baru dengan status `menunggu pembayaran`.
- User diarahkan ke menu Pesanan dan ringkasan pesanan otomatis muncul sebagai pop-up.
- Tombol Bayar sekarang mensimulasikan konfirmasi pembayaran dan mengubah status menjadi `selesai`.
- Tombol Batal pesan menghapus baris pemesanan tersebut (jumlah tiket dalam baris itu ikut terhapus).
- Menu Pesanan memiliki tab Perlu Dibayar dan Selesai.
- Setiap pemesanan baru membuat transaksi/baris baru; transaksi sebelumnya tetap tersimpan sesuai statusnya.

SEBELUM MENGGUNAKAN FITUR PESANAN:
- Buka phpMyAdmin > database cinetix > SQL.
- Jalankan file MIGRASI_STATUS_PEMESANAN.sql satu kali.
- Pembayaran pada versi ini adalah simulasi konfirmasi untuk tugas, bukan transaksi uang sungguhan dan belum terhubung ke payment gateway.

TEMA VISUAL:
- Tampilan diperbarui menjadi tema bioskop cerah: latar putih/abu muda, biru, dan aksen kuning keemasan.
- Referensi visualnya adalah pengalaman situs bioskop modern; identitas dan nama CineTix tetap orisinal.


PEMBARUAN FITUR TERBARU
1. Import satu file database_cinetix.sql melalui phpMyAdmin. File ini berisi struktur database lengkap dan data awal CineTix. Jika database lama berisi data penting, ekspor/backup dahulu sebelum mengimpor ulang.
2. Akun administrator awal: username admin, password admin123. Segera ubah password setelah login.
3. Tabel admin memiliki kolom role_admin: administrator (akses CRUD data administrator) dan admin (hanya dapat melihat daftar administrator).
4. Pengguna memesan tiket -> status menunggu pembayaran. Pengguna menekan Saya sudah bayar -> status menunggu konfirmasi. Administrator mengonfirmasi dari Dashboard Admin -> status selesai.
5. Pilihan studio pada Jadwal Tayang dibatasi Studio 1 sampai Studio 10.
6. Animasi mikro-interaksi diterapkan di halaman utama, detail film, login, daftar, pesanan, dashboard, dan halaman pengelolaan data.


PEMBARUAN FITUR KURSI BIOSKOP DAN CETAK TIKET
1. Sebelum memakai versi ini, buka phpMyAdmin dan pilih database cinetix yang sudah digunakan.
2. Import file database_cinetix.sql. File ini hanya menambahkan tabel pemesanan_kursi dan tidak menghapus data lama.
3. Setiap jadwal tayang memiliki 20 kursi: A1-A5, B1-B5, C1-C5, dan D1-D5.
4. Kursi hijau = tersedia; merah = sudah ditahan/dipesan; kuning = pilihan user.
5. Kursi ditahan sejak pesanan dibuat (menunggu pembayaran) dan tetap ditahan saat menunggu konfirmasi admin.
6. Jika admin mengonfirmasi, status pesanan menjadi selesai dan kursi tetap terpesan.
7. Jika admin membatalkan pesanan yang menunggu konfirmasi, data pemesanan dihapus. Detail kursi otomatis terhapus melalui ON DELETE CASCADE sehingga kursi tersedia kembali.
8. User dapat mencetak tiket pada tab Selesai melalui tombol Cetak Tiket. Halaman tiket akan membuka dialog print browser.
