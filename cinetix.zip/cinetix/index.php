<?php
declare(strict_types=1);
session_start();

require __DIR__ . '/config/database.php';
require __DIR__ . '/models/CrudModel.php';
require __DIR__ . '/models/AuthModel.php';
require __DIR__ . '/models/FilmModel.php';
require __DIR__ . '/controllers/AuthController.php';
require __DIR__ . '/controllers/DashboardController.php';
require __DIR__ . '/controllers/CrudController.php';
require __DIR__ . '/controllers/BookingController.php';

$entities = require __DIR__ . '/config/entities.php';
$auth = new AuthController(new AuthModel($pdo));
$filmModel = new FilmModel($pdo);
$dashboard = new DashboardController($pdo, $filmModel);

function e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function currentUser(): ?array { return $_SESSION['auth'] ?? null; }
function isAdmin(): bool { return (currentUser()['role'] ?? '') === 'admin'; }
function isUser(): bool { return (currentUser()['role'] ?? '') === 'user'; }
function isSuperAdmin(): bool { return isAdmin() && (currentUser()['admin_level'] ?? 'admin') === 'administrator'; }
function requireAdmin(): void { if (!isAdmin()) { header('Location: index.php?page=login'); exit; } }
function redirect(string $url = 'index.php'): never { header('Location: ' . $url); exit; }
function flash(string $message, string $type = 'success'): void { $_SESSION['flash'] = ['message'=>$message, 'type'=>$type]; }
function showFlash(): void {
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        echo '<div class="alert ' . e($f['type']) . '">' . e($f['message']) . '</div>';
        unset($_SESSION['flash']);
    }
}
function csrfToken(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function verifyCsrf(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419);
        exit('Permintaan tidak valid. Muat ulang halaman lalu coba kembali.');
    }
}

$page = $_GET['page'] ?? 'home';
$entity = $_GET['entity'] ?? '';

if ($page === 'logout') {
    $auth->logout();
    redirect();
}

if ($page === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $role = ($_POST['role'] ?? 'user') === 'admin' ? 'admin' : 'user';
    if ($auth->login($role, trim($_POST['username'] ?? ''), $_POST['password'] ?? '')) {
        flash('Berhasil masuk. Selamat datang di CineTix.');
        redirect();
    }
    $error = 'Username atau password tidak sesuai.';
}

if ($page === 'register' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    try {
        $auth->register($_POST);
        flash('Registrasi berhasil. Silakan masuk menggunakan akun yang dibuat.');
        redirect('index.php?page=login');
    } catch (Throwable $ex) {
        $error = $ex instanceof PDOException ? 'Email atau username sudah digunakan. Periksa kembali data registrasi.' : $ex->getMessage();
    }
}

if (in_array($page, ['book','pay','cancel-order'], true) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isUser()) redirect('index.php?page=login');
    verifyCsrf();
    $bookingController = new BookingController($pdo);
    try {
        if ($page === 'book') {
            $newOrderId = $bookingController->create((int)currentUser()['id'], (int)($_POST['id_jadwal'] ?? 0), (array)($_POST['seats'] ?? []));
            redirect('index.php?page=orders&show=' . $newOrderId);
        } elseif ($page === 'pay') {
            $bookingController->pay((int)($_POST['id_pemesanan'] ?? 0), (int)currentUser()['id']);
            flash('Konfirmasi pembayaran terkirim. Pesanan menunggu pemeriksaan administrator.');
        } else {
            $bookingController->cancel((int)($_POST['id_pemesanan'] ?? 0), (int)currentUser()['id']);
            flash('Pesanan berhasil dibatalkan dan tiket pada pesanan tersebut dihapus.');
        }
    } catch (Throwable $ex) {
        flash($ex->getMessage(), 'error');
    }
    redirect('index.php?page=orders');
}

if ($page === 'approve-order' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireAdmin(); verifyCsrf();
    try {
        $stmt = $pdo->prepare("UPDATE pemesanan SET status='selesai' WHERE id_pemesanan=? AND status='menunggu konfirmasi'");
        $stmt->execute([(int)($_POST['id_pemesanan'] ?? 0)]);
        if ($stmt->rowCount() !== 1) throw new RuntimeException('Pesanan tidak ditemukan atau sudah dikonfirmasi.');
        flash('Pembayaran berhasil dikonfirmasi. Pesanan sekarang berstatus selesai.');
    } catch (Throwable $ex) { flash($ex->getMessage(), 'error'); }
    redirect('index.php?page=admin');
}

if ($page === 'cancel-admin-order' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireAdmin(); verifyCsrf();
    try {
        $stmt = $pdo->prepare("DELETE FROM pemesanan WHERE id_pemesanan=? AND status='menunggu konfirmasi'");
        $stmt->execute([(int)($_POST['id_pemesanan'] ?? 0)]);
        if ($stmt->rowCount() !== 1) throw new RuntimeException('Pesanan tidak ditemukan atau sudah diproses.');
        flash('Pesanan dibatalkan. Kursi yang sebelumnya ditahan sekarang tersedia kembali.');
    } catch (Throwable $ex) { flash($ex->getMessage(), 'error'); }
    redirect('index.php?page=admin');
}

if (in_array($page, ['manage','save','delete'], true)) requireAdmin();
if (in_array($page, ['approve-order'], true)) requireAdmin();
if (in_array($page, ['save','delete'], true) && $entity === 'admin' && !isSuperAdmin()) { http_response_code(403); exit('Akses ditolak. Hanya Administrator yang dapat mengelola data administrator.'); }

if ($page === 'save' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($entities[$entity])) {
    verifyCsrf();
    $controller = new CrudController($pdo, $entities[$entity]);
    try {
        $id = (int)($_POST['id'] ?? 0);
        $controller->save($id > 0 ? $id : null, $_POST, $_FILES);
        flash('Data berhasil disimpan.');
    } catch (Throwable $ex) {
        flash($ex instanceof PDOException ? 'Data gagal disimpan. Periksa relasi dan kemungkinan data duplikat.' : $ex->getMessage(), 'error');
    }
    redirect('index.php?page=manage&entity=' . urlencode($entity) . ((int)($_POST['id'] ?? 0) ? '&edit=' . (int)$_POST['id'] : ''));
}

if ($page === 'delete' && isset($entities[$entity])) {
    $controller = new CrudController($pdo, $entities[$entity]);
    try {
        $controller->delete((int)($_GET['id'] ?? 0));
        flash('Data berhasil dihapus.');
    } catch (Throwable $ex) {
        flash('Data tidak dapat dihapus karena masih digunakan oleh data lain atau memiliki relasi.');
    }
    redirect('index.php?page=manage&entity=' . urlencode($entity));
}

$keyword = trim($_GET['q'] ?? '');
$genre = trim($_GET['genre'] ?? '');
$movies = $filmModel->search($keyword, $genre);
$genres = $filmModel->genres();
$detail = null;
$schedules = [];

$occupiedSeatsBySchedule = [];
if ($page === 'detail') {
    $detail = $filmModel->find((int)($_GET['id'] ?? 0));
    if ($detail) {
        $schedules = $filmModel->schedules((int)$detail['id_film']);
        $seatBooking = new BookingController($pdo);
        foreach ($schedules as $scheduleRow) {
            $occupiedSeatsBySchedule[(int)$scheduleRow['id_jadwal']] = $seatBooking->occupiedSeats((int)$scheduleRow['id_jadwal']);
        }
    }
}

if ($page === 'manage' && isset($entities[$entity])) {
    $cfg = $entities[$entity];
    $crud = new CrudController($pdo, $cfg);
    $rows = $crud->all();
    $readOnlyEntity = ($entity === 'admin' && !isSuperAdmin());
    $editRow = (!$readOnlyEntity && isset($_GET['edit'])) ? $crud->find((int)$_GET['edit']) : null;
    $selectOptions = [];
    foreach ($cfg['fields'] as $field) {
        if (($field['type'] ?? '') === 'select' && !isset($field['options'])) $selectOptions[$field['table']] = $crud->optionsFor($field);
    }
}

if ($page === 'print-ticket') {
    if (!isUser()) redirect('index.php?page=login');
    $bookingController = new BookingController($pdo);
    $ticketOrder = $bookingController->findCompletedForUser((int)($_GET['id'] ?? 0), (int)currentUser()['id']);
    if (!$ticketOrder) {
        flash('Tiket hanya dapat dicetak untuk pesanan yang sudah selesai.', 'error');
        redirect('index.php?page=orders&tab=done');
    }
    require __DIR__ . '/views/ticket-print.php';
    exit;
}

if ($page === 'orders') {
    if (!isUser()) redirect('index.php?page=login');
    $bookingController = new BookingController($pdo);
    $pendingOrders = $bookingController->listForUser((int)currentUser()['id'], 'menunggu pembayaran');
    $completedOrders = $bookingController->listForUser((int)currentUser()['id'], 'selesai');
    $confirmationOrders = $bookingController->listForUser((int)currentUser()['id'], 'menunggu konfirmasi');
    $showOrder = isset($_GET['show']) ? $bookingController->findForUser((int)$_GET['show'], (int)currentUser()['id']) : null;
    require __DIR__ . '/views/partials/header.php';
    require __DIR__ . '/views/orders.php';
    require __DIR__ . '/views/partials/footer.php';
    exit;
}

if ($page === 'home' || $page === 'detail') {
    require __DIR__ . '/views/partials/header.php';
    if ($page === 'detail') require __DIR__ . '/views/film-detail.php';
    else require __DIR__ . '/views/home.php';
    require __DIR__ . '/views/partials/footer.php';
    exit;
}

if ($page === 'login' || $page === 'register') {
    require __DIR__ . '/views/auth.php';
    exit;
}

if ($page === 'admin') {
    requireAdmin();
    $stats = $dashboard->stats();
    $recent = $dashboard->recentBookings();
    require __DIR__ . '/views/partials/header.php';
    require __DIR__ . '/views/admin-dashboard.php';
    require __DIR__ . '/views/partials/footer.php';
    exit;
}

if ($page === 'manage' && isset($entities[$entity])) {
    requireAdmin();
    require __DIR__ . '/views/partials/header.php';
    require __DIR__ . '/views/manage.php';
    require __DIR__ . '/views/partials/footer.php';
    exit;
}

redirect();
